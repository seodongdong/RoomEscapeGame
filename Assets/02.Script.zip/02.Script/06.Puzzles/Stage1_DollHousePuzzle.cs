﻿using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// 1스테이지: 인형의 집 퍼즐
///
/// [기획서]
/// - 3D 월드 스페이스에서 직접 프랍을 드래그앤드롭
/// - UI 창 방식 아님. 스냅 기능 없음
/// - 각 슬롯에 작은 인형이 눈을 감고 있음
///   → 맞는 프랍을 드롭하면 인형이 눈을 뜸 (즉시 피드백)
///   → 틀린 프랍을 드롭해도 에러 없음 — 눈은 안 뜸
/// - 모든 슬롯 채워지면 자동 클리어
/// - 퍼즐 완료 시 크리처(인형)가 사라짐
///
/// [구조]
/// - PuzzleDraggableItem : 드래그 가능한 프랍 오브젝트
/// - PuzzleDropZone      : 인형의 집 내 슬롯 (requiredItemId로 정답 판별)
/// - Stage 2와 동일한 드래그앤드롭 시스템 공유
///
/// [PuzzleDropZone 설정]
/// - requiredItemId = "doll_chair" 등 itemId 입력
/// - emptySprite   = 눈 감은 인형 스프라이트
/// - smileSprite   = 눈 뜬 인형 스프라이트 (정답 시)
/// ※ Stage1은 '어디든 놓기' 방식이 아니라 '정답 슬롯에만 눈 뜸' 방식이므로
///   PuzzleDropZone.TryAcceptItem 결과와 무관하게
///   OnItemPlacedOnZone에서 정답 여부를 체크해 시각 처리함
/// </summary>
public class Stage1_DollHousePuzzle : CameraPuzzleBase, PuzzleDropZone.IDropZonePuzzle
{
	[Header("드래그 아이템 목록")]
	[Tooltip("씬에 배치된 PuzzleDraggableItem 오브젝트들을 연결")]
	[SerializeField] private List<PuzzleDraggableItem> dollItems = new List<PuzzleDraggableItem>();

	[Header("드롭존 목록 (인형의 집 슬롯)")]
	[Tooltip("씬에 배치된 PuzzleDropZone 오브젝트들을 연결. requiredItemId를 반드시 설정")]
	[SerializeField] private List<PuzzleDropZone> dollSlots = new List<PuzzleDropZone>();

	[Header("퍼즐 표면 높이")]
	[Tooltip("드래그 평면 Y좌표 — 인형의 집 선반/바닥 높이에 맞춤")]
	[SerializeField] private float dollHouseSurfaceY = 0.5f;

	[Header("나가기 버튼 (선택)")]
	[SerializeField] private UnityEngine.UI.Button exitButton;

	[Header("대사")]
	[SerializeField] private string speaker = "소년";
	[TextArea(2, 4)][SerializeField] private string startDialogue = "인형 장난감을 알맞은 자리에 놓아보자.";
	[TextArea(2, 4)][SerializeField] private string correctDialogue = "맞는 자리인 것 같아!";
	[TextArea(2, 4)][SerializeField] private string wrongDialogue = "...여기가 아닌 것 같다.";
	[TextArea(2, 4)][SerializeField] private string solveDialogue = "인형을 모두 제자리에 찾아줬다!";

	[Header("크리처")]
	[SerializeField] private GameObject creature;

	// ── 캐싱 ─────────────────────────────────────────────────
	private UIManager _uiManager;
	private AudioManager _audioManager;
	private InventoryUI_Complete _inventoryUI;

	// ── 초기화 ────────────────────────────────────────────────

	protected override void Awake()
	{
		base.Awake();

		// 드롭존에 퍼즐 참조 등록
		foreach (var slot in dollSlots)
			if (slot != null) slot.Initialize(this);

		// 나가기 버튼
		if (exitButton != null)
		{
			exitButton.onClick.RemoveAllListeners();
			exitButton.onClick.AddListener(ExitPuzzle);
		}
	}

	protected override void Start()
	{
		base.Start();
		_uiManager = FindAnyObjectByType<UIManager>();
		_audioManager = FindAnyObjectByType<AudioManager>();
		_inventoryUI = FindAnyObjectByType<InventoryUI_Complete>();
	}

	// ── 퍼즐 시작 ────────────────────────────────────────────

	protected override void OnPuzzleStarted()
	{
		base.OnPuzzleStarted();

		// 모든 드래그 아이템 활성화
		foreach (var item in dollItems)
			if (item != null) item.EnableDragging(_mainCamera, dollHouseSurfaceY);

		_uiManager?.ShowDialogue(speaker, startDialogue);
	}

	// ── IDropZonePuzzle 구현 — 아이템이 슬롯에 놓일 때마다 호출 ──

	public void OnItemPlacedOnZone(PuzzleDropZone zone)
	{
		// 정답 체크
		bool isCorrect = zone.IsCorrectlyFilled;

		if (isCorrect)
		{
			// 눈 뜨기 시각 처리는 PuzzleDropZone.TryAcceptItem → smileSprite 이미 처리됨
			_uiManager?.ShowDialogue(speaker, correctDialogue);
			_audioManager?.PlaySFX("puzzle_correct");
		}
		else
		{
			// 틀린 슬롯 — 대사만 (인형 눈은 안 뜸, emptySprite 유지)
			// PuzzleDropZone은 이미 smileSprite로 바꿨으므로 다시 emptySprite로 복원
			zone.RemoveItem();

			// 아이템을 원래 집으로 돌려보냄
			// (PuzzleDropZone.RemoveItem이 slot을 비워주므로 아이템은 그 자리에 그대로)
			_uiManager?.ShowDialogue(speaker, wrongDialogue);
			_audioManager?.PlaySFX("puzzle_wrong");
		}

		// 전체 정답 체크
		CheckSolution();
	}

	// ── 정답 판정 ────────────────────────────────────────────

	protected override bool IsSolutionCorrect()
	{
		foreach (var slot in dollSlots)
		{
			if (slot == null) continue;
			if (!slot.IsCorrectlyFilled) return false;
		}
		return true;
	}

	// ── 퍼즐 해결 ────────────────────────────────────────────

	protected override void SolvePuzzle()
	{
		// 마지막 슬롯에 bigSmile 표정 적용
		foreach (var slot in dollSlots)
			slot?.SetBigSmileExpression();

		// 드래그 비활성화
		foreach (var item in dollItems)
			item?.DisableDragging();

		_uiManager?.ShowDialogue(speaker, solveDialogue);
		_audioManager?.PlaySFX("door_unlock");

		// base: isSolved=true, OnPuzzleSolved 이벤트, ExitPuzzle
		base.SolvePuzzle();

		// 크리처 비활성화
		if (creature != null)
			creature.SetActive(false);
	}

	// ── 퍼즐 나가기 ──────────────────────────────────────────

	public override void ExitPuzzle()
	{
		// 나갈 때 드래그 비활성화 (해결 안 된 상태로 나가는 경우)
		if (!isSolved)
		{
			foreach (var item in dollItems)
				item?.DisableDragging();

			// 기획서: "풀다가 나가면 리셋 (처음부터 다시 시작)"
			ResetPuzzle();
		}

		base.ExitPuzzle();
	}

	// ── 리셋 ─────────────────────────────────────────────────

	private void ResetPuzzle()
	{
		// 모든 슬롯 초기화
		foreach (var slot in dollSlots)
			slot?.RemoveItem();

		// 모든 아이템 원위치
		foreach (var item in dollItems)
			item?.ResetToHomePosition();

		Debug.Log("[Stage1DollHouse] 퍼즐 리셋");
	}

	// ── 기즈모 ────────────────────────────────────────────────

	private void OnDrawGizmos()
	{
		if (dollSlots == null) return;
		Gizmos.color = Color.cyan;
		foreach (var slot in dollSlots)
			if (slot != null)
				Gizmos.DrawWireSphere(slot.transform.position, 0.2f);
	}
}