using UnityEngine;
using System.Collections;

/// <summary>
/// 카메라 전환 기반 퍼즐의 베이스 클래스.
/// 퍼즐 진입 시 카메라를 지정된 위치로 이동시키고,
/// 완료/나가기 시 원래 위치로 복귀합니다.
///
/// [수정 사항]
/// 1. puzzleCameraPosition null 체크 → 없으면 카메라 이동 없이 그냥 시작
/// 2. GameManager.Instance?.StateManager (NullRef 방지)
/// 3. _mainCamera null 체크 → Camera.main 재탐색 fallback
/// 4. _isExiting 플래그 → ExitPuzzle 중복 호출 방지
/// 5. _isTransitioning 플래그 → 전환 중 StartPuzzle 재진입 방지
/// </summary>
public abstract class CameraPuzzleBase : MonoBehaviour, IPuzzle
{
	[Header("Puzzle Settings")]
	[SerializeField] protected string puzzleId;
	[SerializeField] protected bool isSolved;

	[Header("Camera Settings")]
	[Tooltip("퍼즐 카메라 위치. 비워두면 카메라 이동 없이 현재 위치에서 퍼즐 시작.")]
	[SerializeField] protected Transform puzzleCameraPosition;
	[SerializeField] protected float cameraTransitionDuration = 1f;
	[SerializeField]
	protected AnimationCurve cameraTransitionCurve
		= AnimationCurve.EaseInOut(0, 0, 1, 1);

	[Header("UI (선택 — 월드 스페이스 퍼즐은 비워두세요)")]
	[SerializeField] protected GameObject puzzleUI;

	// ── 캐싱 ─────────────────────────────────────────────────
	protected Camera _mainCamera;
	protected Transform _originalCameraParent;
	protected Vector3 _originalCameraPosition;
	protected Quaternion _originalCameraRotation;
	protected Player _player;

	// ── 상태 플래그 ───────────────────────────────────────────
	private bool _isTransitioning = false;  // 카메라 전환 중 재진입 방지
	private bool _isExiting = false;  // ExitPuzzle 중복 호출 방지

	// ── IPuzzle ───────────────────────────────────────────────
	public string PuzzleId => puzzleId;
	public bool IsSolved => isSolved;
	public event System.Action OnPuzzleSolved;

	// ── 초기화 ────────────────────────────────────────────────
	protected virtual void Awake()
	{
		// ★ Camera.main null 체크 → Start에서 재시도 가능하도록 분리
		_mainCamera = Camera.main;
		_player = FindAnyObjectByType<Player>();
	}

	protected virtual void Start()
	{
		// Awake에서 못 찾은 경우 Start에서 재탐색
		if (_mainCamera == null)
			_mainCamera = Camera.main;
		if (_player == null)
			_player = FindAnyObjectByType<Player>();
	}

	// ── 퍼즐 시작 ────────────────────────────────────────────

	public virtual void StartPuzzle()
	{
		// 이미 해결됐거나 전환 중이면 무시
		if (isSolved) return;
		if (_isTransitioning) return;

		// ★ null 안전 체크
		if (_mainCamera == null)
		{
			_mainCamera = Camera.main;
			if (_mainCamera == null)
			{
				Debug.LogError($"[Puzzle:{puzzleId}] Camera.main을 찾을 수 없습니다!");
				return;
			}
		}

		_isExiting = false;
		_isTransitioning = true;

		GameManager.Instance?.StateManager.ChangeState(GameState.Puzzle);

		FindAnyObjectByType<UIManager>()?.HideInteractionPrompt();

		// 플레이어 비활성화 + 메시 숨김
		if (_player != null)
		{
			_player.enabled = false;
			SetPlayerMeshVisible(false);
		}

		Cursor.lockState = CursorLockMode.None;
		Cursor.visible = true;

		// 원래 카메라 상태 저장
		_originalCameraParent = _mainCamera.transform.parent;
		_originalCameraPosition = _mainCamera.transform.position;
		_originalCameraRotation = _mainCamera.transform.rotation;
		_mainCamera.transform.SetParent(null);

		StartCoroutine(TransitionCamera(true));
	}

	// ── 카메라 전환 ──────────────────────────────────────────

	protected virtual IEnumerator TransitionCamera(bool toPuzzle)
	{
		Vector3 startPos = _mainCamera.transform.position;
		Quaternion startRot = _mainCamera.transform.rotation;
		Vector3 endPos;
		Quaternion endRot;

		if (toPuzzle)
		{
			// ★ puzzleCameraPosition null 체크
			if (puzzleCameraPosition != null)
			{
				endPos = puzzleCameraPosition.position;
				endRot = puzzleCameraPosition.rotation;
			}
			else
			{
				// 카메라 이동 없이 현재 위치에서 퍼즐 시작
				endPos = startPos;
				endRot = startRot;
				Debug.LogWarning($"[Puzzle:{puzzleId}] puzzleCameraPosition이 없습니다. 현재 위치에서 시작합니다.");
			}
		}
		else
		{
			endPos = _originalCameraPosition;
			endRot = _originalCameraRotation;
		}

		// 카메라 이동이 필요 없으면 즉시 완료
		bool needsTransition = Vector3.Distance(startPos, endPos) > 0.01f
							   || Quaternion.Angle(startRot, endRot) > 0.1f;

		if (needsTransition && cameraTransitionDuration > 0f)
		{
			float elapsed = 0f;
			while (elapsed < cameraTransitionDuration)
			{
				elapsed += Time.unscaledDeltaTime;
				float t = cameraTransitionCurve.Evaluate(
					Mathf.Clamp01(elapsed / cameraTransitionDuration));
				_mainCamera.transform.position = Vector3.Lerp(startPos, endPos, t);
				_mainCamera.transform.rotation = Quaternion.Slerp(startRot, endRot, t);
				yield return null;
			}
		}

		_mainCamera.transform.position = endPos;
		_mainCamera.transform.rotation = endRot;

		_isTransitioning = false;

		if (toPuzzle)
		{
			if (puzzleUI != null) puzzleUI.SetActive(true);
			OnPuzzleStarted();
		}
		else
		{
			_mainCamera.transform.SetParent(_originalCameraParent);
			OnPuzzleExited();
		}
	}

	protected virtual void OnPuzzleStarted()
	{
		Debug.Log($"[Puzzle:{puzzleId}] 퍼즐 시작");
	}

	protected virtual void OnPuzzleExited()
	{
		Debug.Log($"[Puzzle:{puzzleId}] 퍼즐 종료");
	}

	// ── 정답 체크 ────────────────────────────────────────────

	public virtual void CheckSolution()
	{
		if (IsSolutionCorrect())
			SolvePuzzle();
	}

	protected abstract bool IsSolutionCorrect();

	protected virtual void SolvePuzzle()
	{
		isSolved = true;
		if (puzzleUI != null) puzzleUI.SetActive(false);
		OnPuzzleSolved?.Invoke();
		Debug.Log($"[Puzzle:{puzzleId}] 해결 완료!");
		ExitPuzzle();
	}

	// ── 퍼즐 나가기 ──────────────────────────────────────────

	public virtual void ExitPuzzle()
	{
		// ★ 중복 호출 방지
		if (_isExiting) return;
		_isExiting = true;

		if (puzzleUI != null) puzzleUI.SetActive(false);
		StartCoroutine(ExitPuzzleCoroutine());
	}

	protected virtual IEnumerator ExitPuzzleCoroutine()
	{
		yield return StartCoroutine(TransitionCamera(false));

		// ★ null 안전 체크
		GameManager.Instance?.StateManager.ChangeState(GameState.Playing);

		if (_player != null)
		{
			_player.enabled = true;
			SetPlayerMeshVisible(true);
		}

		Cursor.lockState = CursorLockMode.Locked;
		Cursor.visible = false;

		_isExiting = false;
	}

	// ── 헬퍼 ─────────────────────────────────────────────────

	/// <summary>
	/// 퍼즐 진입/퇴장 시 플레이어 메시 표시/숨김
	/// </summary>
	private void SetPlayerMeshVisible(bool visible)
	{
		if (_player == null) return;
		foreach (var mesh in _player.GetComponentsInChildren<MeshRenderer>())
			mesh.enabled = visible;
		foreach (var mesh in _player.GetComponentsInChildren<SkinnedMeshRenderer>())
			mesh.enabled = visible;
	}

	/// <summary>
	/// 하위 클래스에서 OnPuzzleSolved 이벤트를 안전하게 호출할 때 사용
	/// </summary>
	protected void InvokeOnPuzzleSolved() => OnPuzzleSolved?.Invoke();
}