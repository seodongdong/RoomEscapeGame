using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// UI 레이어 스택 관리자
///
/// [기획서 기준]
/// - ESC = 최상위 열린 UI부터 하나씩 닫기
/// - 모든 UI가 닫힌 상태에서 ESC → 일시정지
/// - E키도 창 닫기 동작 (ESC와 동일)
///
/// [사용법]
/// UI가 열릴 때 : UILayerManager.Instance.Push(this, OnClose콜백)
/// UI가 닫힐 때 : UILayerManager.Instance.Pop(this)
/// ESC/E 처리  : Player.cs HandleCursorToggle → 이 클래스에 위임
///
/// [등록 우선순위 예시 — 높을수록 나중에 닫힘]
/// DiaryUI(안에서 열림) > InventoryUI > PauseMenu
/// </summary>
public class UILayerManager : MonoBehaviour
{
	private static UILayerManager _instance;
	public static UILayerManager Instance => _instance;

	// 열린 UI 스택 (UI MonoBehaviour, 닫기 콜백)
	private readonly Stack<(MonoBehaviour owner, System.Action onClose)> _stack
		= new Stack<(MonoBehaviour, System.Action)>();

	// 일시정지 패널 (모든 UI 닫힌 상태에서 ESC 눌렀을 때)
	[Header("Pause")]
	[SerializeField] private GameObject pausePanel;
	[SerializeField] private string pauseSpeaker = "";
	[SerializeField] private string pauseDialogue = "";   // 비워두면 대사 없음

	private bool _isPaused = false;

	private void Awake()
	{
		if (_instance != null && _instance != this) { Destroy(gameObject); return; }
		_instance = this;
		// GameManager처럼 DontDestroyOnLoad 하지 않음
		// → 씬마다 각자 배치해서 씬 전환 시 자동 초기화
	}

	private void OnDestroy()
	{
		if (_instance == this)
		{
			_instance = null;
			_stack.Clear();
		}
	}

	// ─── 외부 호출 ────────────────────────────────────────────

	/// <summary>
	/// UI가 열릴 때 스택에 등록
	/// onClose : ESC/E 눌렸을 때 실행할 닫기 콜백
	/// </summary>
	public void Push(MonoBehaviour owner, System.Action onClose)
	{
		_stack.Push((owner, onClose));
		Debug.Log($"[UILayer] Push: {owner.GetType().Name} (depth={_stack.Count})");
	}

	/// <summary>
	/// UI가 직접 닫힐 때(버튼 등) 스택에서 제거
	/// ESC로 닫힐 때는 HandleEsc()가 Pop까지 처리하므로 중복 호출 방지
	/// </summary>
	public void Pop(MonoBehaviour owner)
	{
		if (_stack.Count == 0) return;

		// 최상위가 본인인지 확인 후 제거
		if (_stack.Peek().owner == owner)
		{
			_stack.Pop();
			Debug.Log($"[UILayer] Pop: {owner.GetType().Name} (depth={_stack.Count})");
		}
		else
		{
			// 중간 레이어가 직접 닫힌 경우 — 스택을 정리
			var temp = new Stack<(MonoBehaviour, System.Action)>();
			while (_stack.Count > 0)
			{
				var item = _stack.Pop();
				if (item.owner == owner) break;
				temp.Push(item);
			}
			while (temp.Count > 0)
				_stack.Push(temp.Pop());
		}
	}

	/// <summary>
	/// Player.cs HandleCursorToggle 대신 여기서 ESC/E를 처리
	/// </summary>
	public void HandleEsc()
	{
		// 열린 UI가 있으면 최상위 닫기
		if (_stack.Count > 0)
		{
			var top = _stack.Pop();
			top.onClose?.Invoke();
			Debug.Log($"[UILayer] ESC → 닫기: {top.owner.GetType().Name}");
			return;
		}

		// 열린 UI 없음 → 일시정지 토글
		TogglePause();
	}

	/// <summary>
	/// 현재 열린 UI가 있는지 여부
	/// Player.cs에서 조작 차단 판단에 사용
	/// </summary>
	public bool HasOpenUI => _stack.Count > 0;

	// ─── 일시정지 ─────────────────────────────────────────────

	private void TogglePause()
	{
		if (_isPaused)
			ResumeGame();
		else
			PauseGame();
	}

	private void PauseGame()
	{
		_isPaused = true;

		if (pausePanel != null)
			pausePanel.SetActive(true);

		Cursor.lockState = CursorLockMode.None;
		Cursor.visible = true;
		GameManager.Instance?.StateManager.ChangeState(GameState.Paused);
		Debug.Log("[UILayer] 일시정지");
	}

	public void ResumeGame()
	{
		_isPaused = false;

		if (pausePanel != null)
			pausePanel.SetActive(false);

		Cursor.lockState = CursorLockMode.Locked;
		Cursor.visible = false;
		GameManager.Instance?.StateManager.ChangeState(GameState.Playing);
		Debug.Log("[UILayer] 재개");
	}

	public bool IsPaused => _isPaused;
}