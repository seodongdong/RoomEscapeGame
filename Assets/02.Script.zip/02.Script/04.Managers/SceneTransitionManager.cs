using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.Collections;

/// <summary>
/// �� ��ȯ ����
/// ���̵� ȿ�� ����
/// </summary>
public class SceneTransitionManager : MonoBehaviour
{
	private static SceneTransitionManager _instance;
	public static SceneTransitionManager Instance => _instance;

	[Header("Fade Settings")]
	[SerializeField] private Image fadeImage;
	[SerializeField] private float fadeDuration = 1f;

	[Header("Loading")]
	[SerializeField] private GameObject loadingPanel;
	[SerializeField] private Slider loadingBar;

	private void Awake()
	{
		if (_instance != null && _instance != this)
		{
			Destroy(gameObject);
			return;
		}

		_instance = this;
		DontDestroyOnLoad(gameObject);
	}

	/// <summary>
	/// �� ��ȯ (���̵� ȿ��)
	/// </summary>
	public void LoadScene(string sceneName)
	{
		StartCoroutine(LoadSceneCoroutine(sceneName));
	}

	/// <summary>
	/// �� ��ȯ (�ε���)
	/// </summary>
	public void LoadScene(int sceneIndex)
	{
		StartCoroutine(LoadSceneCoroutine(sceneIndex));
	}

	private IEnumerator LoadSceneCoroutine(string sceneName)
	{
		// ���̵� �ƿ�
		yield return StartCoroutine(FadeOut());

		// �ε� �г� ǥ��
		if (loadingPanel != null)
		{
			loadingPanel.SetActive(true);
		}

		// �� �ε�
		AsyncOperation asyncLoad = SceneManager.LoadSceneAsync(sceneName);
		asyncLoad.allowSceneActivation = false;

		// �ε� �� ������Ʈ
		while (!asyncLoad.isDone)
		{
			float progress = Mathf.Clamp01(asyncLoad.progress / 0.9f);

			if (loadingBar != null)
			{
				loadingBar.value = progress;
			}

			if (asyncLoad.progress >= 0.9f)
			{
				asyncLoad.allowSceneActivation = true;
			}

			yield return null;
		}

		// �ε� �г� ����
		if (loadingPanel != null)
		{
			loadingPanel.SetActive(false);
		}

		// ���̵� ��
		yield return StartCoroutine(FadeIn());
	}

	private IEnumerator LoadSceneCoroutine(int sceneIndex)
	{
		yield return StartCoroutine(FadeOut());

		SceneManager.LoadScene(sceneIndex);

		yield return StartCoroutine(FadeIn());
	}

	private IEnumerator FadeOut()
	{
		if (fadeImage == null) yield break;

		fadeImage.gameObject.SetActive(true);
		float elapsed = 0f;
		Color color = fadeImage.color;

		while (elapsed < fadeDuration)
		{
			elapsed += Time.deltaTime;
			color.a = elapsed / fadeDuration;
			fadeImage.color = color;
			yield return null;
		}

		color.a = 1f;
		fadeImage.color = color;
	}

	private IEnumerator FadeIn()
	{
		if (fadeImage == null) yield break;

		float elapsed = 0f;
		Color color = fadeImage.color;

		while (elapsed < fadeDuration)
		{
			elapsed += Time.deltaTime;
			color.a = 1f - (elapsed / fadeDuration);
			fadeImage.color = color;
			yield return null;
		}

		color.a = 0f;
		fadeImage.color = color;
		fadeImage.gameObject.SetActive(false);
	}

	/// <summary>
	/// ��� �� ��ȯ (���̵� ����)
	/// </summary>
	public void LoadSceneImmediate(string sceneName)
	{
		SceneManager.LoadScene(sceneName);
	}
}