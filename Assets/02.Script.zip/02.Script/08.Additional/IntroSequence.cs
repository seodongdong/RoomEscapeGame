using UnityEngine;
using System.Collections;
using UnityEngine.UI;

/// <summary>
/// ��Ʈ�� ����
/// ��ȹ��: ���� ȭ�� �� ��� �� �ҳ� ù ����
/// </summary>
public class IntroSequence : MonoBehaviour
{
	[Header("References")]
	[SerializeField] private Player player;
	[SerializeField] private Girl girl;
	[SerializeField] private Transform doorPosition;

	[Header("Cameras")]
	[SerializeField] private Camera introCamera;
	[SerializeField] private Camera playerCamera;

	[Header("Fade")]
	[SerializeField] private Image fadeImage;
	[SerializeField] private float fadeDuration = 2f;

	[Header("Dialogue")]
	[SerializeField] private string speaker = "�ҳ�";
	[TextArea(2, 5)]
	[SerializeField] private string wakeUpDialogue = "...���Ⱑ �����?";


	private IUIManager _uiManager;

	private void Start()
	{
		_uiManager = FindAnyObjectByType<UIManager>();
		StartCoroutine(PlayIntro());
	}

	private IEnumerator PlayIntro()
	{
		// �÷��̾� ���� ��Ȱ��ȭ
		if (player != null)
		{
			player.enabled = false;
		}

		// ���� ����
		GameManager.Instance.StateManager.ChangeState(GameState.MainMenu);

		// 1. ���̵� ��
		yield return StartCoroutine(FadeIn());

		// 2. ���
		_uiManager?.ShowDialogue(speaker, wakeUpDialogue);
		yield return new WaitForSeconds(3f);

		// 3. ī�޶� ��ȯ
		if (introCamera != null && playerCamera != null)
		{
			introCamera.gameObject.SetActive(false);
			playerCamera.gameObject.SetActive(true);
		}

		// 4. �÷��̾� Ȱ��ȭ
		if (player != null)
		{
			player.enabled = true;
		}

		// 5. ��� ��� �� �ҳ� ����
		yield return new WaitForSeconds(4f);  // ������ �ø���
		girl?.FirstMeeting();

		// 6. ���� ����
		yield return new WaitForSeconds(5f);
		GameManager.Instance.StateManager.ChangeState(GameState.Playing);
	}

	private IEnumerator FadeIn()
	{
		if (fadeImage == null) yield break;

		float elapsed = 0f;
		Color color = fadeImage.color;

		while (elapsed < fadeDuration)
		{
			elapsed += Time.deltaTime;
			color.a = 1f - (elapsed / fadeDuration);
			fadeImage.color = color;
			yield return null;
		}

		color.a = 0f;
		fadeImage.color = color;
		fadeImage.gameObject.SetActive(false);
	}

	private IEnumerator FadeOut()
	{
		if (fadeImage == null) yield break;

		fadeImage.gameObject.SetActive(true);
		float elapsed = 0f;
		Color color = fadeImage.color;

		while (elapsed < fadeDuration)
		{
			elapsed += Time.deltaTime;
			color.a = elapsed / fadeDuration;
			fadeImage.color = color;
			yield return null;
		}

		color.a = 1f;
		fadeImage.color = color;
	}
}